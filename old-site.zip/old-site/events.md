---
layout: page
title: Upcoming Events
permalink: /events/
---

#### **please check the Facebook page & your email for more information and updates!!!**

-**9/4 3-6 PM** Involvement Fair: College Avenue<br><br>
-**9/14 8 PM** First General Meeting: Hill Center 248<br><br>
-**9/21 6-7:30 PM** Google + WITI Interview Readiness Workshop (Focused on Juniors/Seniors)<br><br>
-**9/26 7:30-8:30 PM** Bank of America Networking Reception with Representatives from Global Technology Business: International Lounge<br><br>
-**10/18 6-7:30 PM** Google Interview Readiness Workshop (Focused on Freshman/Sophomores): Busch Campus Center 117
<br><br>
-**10/23 Time 8 PM** Second General Meeting: Hill Center 248
